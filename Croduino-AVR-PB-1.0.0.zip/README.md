Croduino boards for Arduino IDE manager. 

Will be updated